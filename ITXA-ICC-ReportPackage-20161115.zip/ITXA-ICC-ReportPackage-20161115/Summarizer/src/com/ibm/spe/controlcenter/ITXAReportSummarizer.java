/*
 * IBM Standards Processing Engine
 * IBM Confidential OCO Source Materials
 * (C) Copyright IBM Corp. 2016  All Rights Reserved.
 * The source code for this program is not published or otherwise divested of its
 * trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
 */
package com.ibm.spe.controlcenter;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import com.ibm.cc.model.Event;
import com.ibm.cc.model.EventType;
import com.ibm.cc.model.FileTransfer;
import com.ibm.cc.model.Process;
import com.ibm.tenx.core.log.Logger;
import com.ibm.tenx.db.PersistenceSession;
import com.sterlingcommerce.scc.agent.SCCAgent;
import com.sterlingcommerce.scc.common.CCTimeZones;

// com.ibm.cc.model.* classes are in ccwc-6.x.jar from {icc_install}/lib/10x_Jars
// com.sterlingcommerce.scc.agent.SCCAgent is in SCCenter.jar from {icc_install}/lib/sterling
// com.sterlingcommerce.scc.common.CCTimeZones is in SCCenter.jar from {icc_install}/lib/sterling
// com.sterlingcommerce.scc.agent.event.DefaultSummarizer is in process-summarizer-sdk-1.1.0.jar

/**
 * This class is used by IBM Control Center (ICC) to pull out the event data sent to it from
 * ITXA and separate it into different tables that are easier to query for the COGNOS reports.
 * There are four ITXA tables that need to exist in the ICC database:
 * <pre>
 * SPE_CORRELATION_INTERCHANGE
 * SPE_CORRELATION_GROUP
 * SPE_CORRELATION_TRANSACTION
 * SPE_CORRELATION_OTHER
 * </pre>
 * This summarizer will extract the event meta data that is associated with each table and insert it.
 * All interchange meta data name value pairs that consistently repeat will go in the SPE_CORRELATION_INTERCHANGE table.
 * The idea is to prevent multiple queries on the same table like SI does with the CORRELATION_SET table.
 * In SI, you have several multiple query joins because each piece of information to query on exists in different rows.
 * Here all the interchange info exists in one record.
 *
 * The SPE_CORRELATION_OTHER table is formatted just like the CORRELATION_SET table in SI as a set of name value pairs.
 * This table holds the meta data that can't be formatted into one row or doesn't occur enough times to warrant a place in a long record.
 * For example TransactionControlNumber can appear multiple times and will therefore not fit in a single row in the SPE_CORRELATION_TRANSACTION table.
 * Therefore this specific piece of meta data will be stored and repeated in the SPE_CORRELATION_OTHER table.
 * This table is indexed on NAME, VALUE, and OBJECT_ID fields to prevent duplicates from being stored.
 * If duplicates are found then they are simply dropped much like SI does today when they're encountered.
 *
 * The summarizer supports the EDITransDetail and EDIOutAck reports.
 * Other standards can be supported by this summarizer provided they create similar correlations.
 * The biggest caveat will be for ACK reconciliation.
 * You need to make sure a driverTrackingType called RECONCILE (not case sensitive) is created.
 * This will tell the summarizer that the record already exists and needs to be updated.
 * The reconcile record would have been created during a previous out bound scenario.
 *
 * To configure the ITXA summarizer used in control center, start the ICC web console (http://localhost:58082/sccwebclient/manage),
 * navigate to the System configuration page, select the ITXA view, and enter the following as the Process summarizer:
 * com.ibm.spe.controlcenter.ITXAReportSummarizer
 * If no reports are needed, then enter:
 * com.ibm.spe.controlcenter.ITXABaseSummarizer
 *
 * @author Chris Moore
 */
public class ITXAReportSummarizer extends ITXABaseSummarizer {
	private static final String InsertInter = "INSERT INTO SPE_CORRELATION_INTERCHANGE(STANDARD, SENDER_ID, SENDER_ID_QUALIFIER, RECEIVER_ID, RECEIVER_ID_QUALIFIER, ENVELOPE_NAME, ENVELOPE_TYPE, ENVELOPE_VERSION, CONTROL_NUMBER, COMPLIANCE_STATUS, ACK_REQUESTED, ACK_STATUS, ACK_OVERDUE_TIME, CHILD_COUNT, DIRECTION, DOCUMENT_SIZE, INTERCHANGE_DATE, OBJECT_ID, CREATE_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String InsertGroup = "INSERT INTO SPE_CORRELATION_GROUP(STANDARD, SENDER_ID, SENDER_ID_QUALIFIER, RECEIVER_ID, RECEIVER_ID_QUALIFIER, ENVELOPE_NAME, ENVELOPE_TYPE, ENVELOPE_VERSION, VERSION, CONTROL_NUMBER, FUNCTIONAL_ID, COMPLIANCE_STATUS, ACK_STATUS, ACK_OVERDUE_TIME, CHILD_COUNT, DIRECTION, DOCUMENT_SIZE, GROUP_DATE, CONTAINER_DOC_ID, OBJECT_ID, CREATE_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String InsertTrans = "INSERT INTO SPE_CORRELATION_TRANSACTION(STANDARD, SENDER_ID, SENDER_ID_QUALIFIER, RECEIVER_ID, RECEIVER_ID_QUALIFIER, ENVELOPE_NAME, ENVELOPE_TYPE, ENVELOPE_VERSION, VERSION, TRANSACTION_SET_ID, COMPLIANCE_STATUS, DIRECTION, DOCUMENT_SIZE, TRANSACTION_DATE, TRANSACTION_COUNT, CONTAINER_DOC_ID, OBJECT_ID, CREATE_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String InsertOther = "INSERT INTO SPE_CORRELATION_OTHER(NAME, VALUE, OBJECT_ID, CREATE_DATE) VALUES(?,?,?,?)";
	private static final String UpdateInter = "UPDATE SPE_CORRELATION_INTERCHANGE SET ACK_STATUS=? WHERE OBJECT_ID=?";
	private static final String UpdateGroup = "UPDATE SPE_CORRELATION_GROUP SET ACK_STATUS=? WHERE OBJECT_ID=?";

	private static final String SplitRegex = "\\s*,\\s*";
	private static final String Level = "Level";
	private static final String Standard = "Standard";
	private static final String Direction = "Direction";
	private static final String RECONCILE = "RECONCILE";
	private static final String DOCUMENT_ID = "DOCUMENT_ID";
	private static final String attachments = "attachments";
	private static final String DocumentSize = "DocumentSize";
	private static final String ContainerDocID = "ContainerDocID";
	private static final String DriverTrackingType = "DriverTrackingType";
	private static final String HasMultipleValues = " has multiple values but only the last one will be used: ";

	private static final String INTERCHANGE = "INTERCHANGE";
	private static final String InterchangeDateTime = "InterchangeDateTime";
	private static final String InterchangeSenderID = "InterchangeSenderID";
	private static final String InterchangeAckStatus = "InterchangeAckStatus";
	private static final String InterchangeReceiverID = "InterchangeReceiverID";
	private static final String InterchangeOverdueTime = "InterchangeOverdueTime";
	private static final String InterchangeAckRequested = "InterchangeAckRequested";
	private static final String InterchangeEnvelopeName = "InterchangeEnvelopeName";
	private static final String InterchangeEnvelopeType = "InterchangeEnvelopeType";
	private static final String InterchangeControlNumber = "InterchangeControlNumber";
	private static final String InterchangeEnvelopeVersion = "InterchangeEnvelopeVersion";
	private static final String InterchangeComplianceStatus = "InterchangeComplianceStatus";
	private static final String InterchangeSenderIDQualifier = "InterchangeSenderIDQualifier";
	private static final String InterchangeReceiverIDQualifier = "InterchangeReceiverIDQualifier";

	private static final String GROUP = "GROUP";
	private static final String GroupCount = "GroupCount";
	private static final String FunctionalID = "FunctionalID";
	private static final String GroupVersion = "GroupVersion";
	private static final String GroupDateTime = "GroupDateTime";
	private static final String GroupSenderID = "GroupSenderID";
	private static final String GroupAckStatus = "GroupAckStatus";
	private static final String GroupReceiverID = "GroupReceiverID";
	private static final String GroupOverdueTime = "GroupOverdueTime";
	private static final String GroupEnvelopeName = "GroupEnvelopeName";
	private static final String GroupEnvelopeType = "GroupEnvelopeType";
	private static final String GroupControlNumber = "GroupControlNumber";
	private static final String GroupEnvelopeVersion = "GroupEnvelopeVersion";
	private static final String GroupComplianceStatus = "GroupComplianceStatus";
	private static final String GroupSenderIDQualifier = "GroupSenderIDQualifier";
	private static final String GroupReceiverIDQualifier = "GroupReceiverIDQualifier";

	private static final String TRANSACTION = "TRANSACTION";
	private static final String TransactionCount = "TransactionCount";
	private static final String TransactionSetID = "TransactionSetID";
	private static final String TransactionVersion = "TransactionVersion";
	private static final String TransactionDateTime = "TransactionDateTime";
	private static final String TransactionSenderID = "TransactionSenderID";
	private static final String TransactionReceiverID = "TransactionReceiverID";
	private static final String TransactionEnvelopeName = "TransactionEnvelopeName";
	private static final String TransactionEnvelopeType = "TransactionEnvelopeType";
	private static final String TransactionEnvelopeVersion = "TransactionEnvelopeVersion";
	private static final String TransactionComplianceStatus = "TransactionComplianceStatus";
	private static final String TransactionSenderIDQualifier = "TransactionSenderIDQualifier";
	private static final String TransactionReceiverIDQualifier = "TransactionReceiverIDQualifier";

	private static final SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy hh:mm:ss a");
	private static final Logger Log = Logger.getLogger(ITXAReportSummarizer.class);
	private static final String NL = System.getProperty("line.separator");
	private int levelSize = 0; // Used when debugging.
	protected boolean debugToStdOut = false;
	protected boolean debug = false;

	/** Default constructor. */
	public ITXAReportSummarizer() {
		super();
		debug = Log.isDebugEnabled();

		// Look for {ccInstall}/conf/itxa.properties file.  Current user.dir={ccInstall}/bin
		Properties p = getProperties("../conf/itxa.properties");
		if ( p != null ) {
			if ( !debug ) { // Keep from resetting if ccInstall\conf\Engine.log4j has log4j.rootLogger=DEBUG, R
				debug = "true".equalsIgnoreCase(p.getProperty("ITXAReportSummarizer.debug"));
			}
			debugToStdOut = "true".equalsIgnoreCase(p.getProperty("ITXAReportSummarizer.logDebugMessagesToStandardOut"));
		}

		// UTC is not a time zone, it's a time standard but ICC sets it to UTC.
		if ( "UTC".equals(TimeZone.getDefault().getID()) ) {
			String zone = SCCAgent.getConfiguredTimeZoneId();
			if ( zone != null && !zone.isEmpty() ) {
				TimeZone tz = CCTimeZones.getTimeZone(zone);
				sdf.setTimeZone(tz); // Apply the time zone to the date format so it comes out right.
			} else {
				p = getProperties("../conf/InstallationInfo.properties"); // Try to get the real time zone.
				if ( p != null ) {
					// Get the identifier in the form: country/region - i.e. America/New_York = EST/EDT
					zone = p.getProperty("CCENTER_TIMEZONE");
					if ( zone != null && !zone.isEmpty() ) {
						TimeZone tz = TimeZone.getTimeZone(zone);
						sdf.setTimeZone(tz); // Apply the time zone to the date format so it comes out right.
					}
				}
			}
		}
	}

	// The main entry point called by the Control Center SDK.
	@Override
	public Collection<FileTransfer> summarize(Process process, List<Event> events) {
		// Must call the super method prior to processing the events.
		Collection<FileTransfer> transfers = super.summarize(process, events);
		if ( events != null ) {
			if ( debug ) {
				logMsg("ITXA.summarize events size=" + events.size(), null, false);
			}
			int type = -1;
			String driverTrackingType = null;
			Map<String, String> eventMap = null;
			for ( Event event : events ) {
				if ( event != null ) {
					// This is the name value pair collection that ITXA sent ICC.
					if ( (eventMap = event.getXmlValues()) != null ) {
						// Only summarize PROCESS_STATUS or STEP_START events.
						type = event.getTypeInt();
						if ( type == EventType.PROCESS_STATUS || type == EventType.STEP_START ) {
							// Only summarize events with DriverTrackingType.
							driverTrackingType = eventMap.get(DriverTrackingType);
							if ( driverTrackingType != null ) {
								// Summarize the correlation data created by EDI processing.
								summarizeData(eventMap, driverTrackingType);
							} else if ( debug ) {
								final String type2str = event.getTypeEnum().toString();
								logMsg(type2str, " but no DriverTrackingType with eventMap=", eventMap.toString());
							}
						} else if ( debug ) {
							final String type2str = event.getTypeEnum().toString();
							logMsg(type2str, " with eventMap=", eventMap.toString());
						}
					} else if ( debug ) {
						final String type2str = event.getTypeEnum().toString();
						logMsg(type2str, " but eventMap is null", null);
					}
				}
			}
		}
		return transfers; // Return results from super.summarize method.
	}

	/** Extracts the meta data from the map and stores them into the appropriate tables.
	 * @param eventMap A non-null map of document meta data from ITXA.
	 * @param driverTrackingType The driver tracking type. */
	private void summarizeData(Map<String, String> eventMap, String driverTrackingType) {
		// Get a database connection from the SDK.
		Connection conx = PersistenceSession.currentSession().getConnection();
		if ( conx != null ) {
			try {
				String docId = eventMap.remove(DOCUMENT_ID);
				if ( debug ) {
					StringBuilder sb = new StringBuilder(200);
					sb.append("ITXA.summarizeData");
					sb.append(" driverTrackingType=").append(driverTrackingType);
					sb.append(" docId=").append(docId);
					sb.append(" eventMap=").append(eventMap.toString());
					logMsg(sb.toString(), null, false);
				}
				// The ACK reconciliation process in ITXA should be creating a tracking type of RECONCILE.
				// This will indicate an update will occur.  Example: Update ACK from WAITING to ACCEPTED state.
				if ( RECONCILE.equalsIgnoreCase(driverTrackingType) ) {
					// These are ACK related events.
					// Update the record created for the out bound interchange.
					updateReconcileRow(conx, eventMap, docId);
				} else {
					boolean hasStandard = eventMap.containsKey(Standard);
					String keyValue = eventMap.get(Level); // Level=[Transaction, Group]
					if ( hasStandard && keyValue != null ) {
						int levelIndex = 0;
						String[] levels = keyValue.split(SplitRegex);
						if ( debug ) {
							if ( (levelSize = levels.length) > 1 ) {
								StringBuilder sb = new StringBuilder(200);
								sb.append("ITXA.summarizeData levels.size=").append(levelSize);
								sb.append(" ").append(Arrays.asList(levels));
								logMsg(sb.toString(), null, false);
							}
						}
						for ( String level : levels ) {
							if ( debug ) {
								logMsg("ITXA.summarizeData level=" + level, null, false);
							}
							if ( TRANSACTION.equalsIgnoreCase(level) ) {
								createTransactionRow(conx, eventMap, docId, levelIndex++);
							} else if ( GROUP.equalsIgnoreCase(level) ) {
								createGroupRow(conx, eventMap, docId, levelIndex++);
							} else if ( INTERCHANGE.equalsIgnoreCase(level) ) {
								createInterchangeRow(conx, eventMap, docId, levelIndex++);
							}
						}
					}
					// The loop above iterates over the comma separated level values for the same map.
					// An enveloping level will therefore be processed once for each iteration.
					// Persisting the other correlations must occur after each level above has been processed so that's why its done here.
					if ( hasStandard ) {
						persistOtherCorrelations(conx, eventMap, docId);
					}
				}
			} finally {
				try {
					conx.close();
				} catch (Throwable t) {
					logMsg("ITXA.summarizeData exception.", t, true);
				}
			}
		} else {
			logMsg("ITXA.summarizeData unable to get database connection.", null, true);
		}
	}

	/** Update the ACK record in the table corresponding to the document.
	 * @param conx The JDBC connection.
	 * @param eventMap The document meta data.
	 * @param docId The document identifier that represents the ACK record in ITXA. */
	private void updateReconcileRow(Connection conx, Map<String, String> eventMap, String docId) {
		PreparedStatement pStatement1 = null;
		PreparedStatement pStatement2 = null;
		String interchangeAckStatus = null;
		String groupAckStatus = null;
		String keyValue = null;
		String[] values = null;

		for ( String key : eventMap.keySet() ) {
			keyValue = eventMap.get(key);
			if ( keyValue != null ) {
				values = keyValue.split(SplitRegex);
				for ( String value : values ) {
					if ( InterchangeAckStatus.equals(key) ) {
						interchangeAckStatus = value;
					} else if ( GroupAckStatus.equals(key) ) {
						groupAckStatus = value;
					}
				}
			}
		}
		try {
			if ( interchangeAckStatus != null ) {
				pStatement1 = conx.prepareStatement(UpdateInter);
				pStatement1.setString(1, interchangeAckStatus);
				pStatement1.setString(2, docId);
				pStatement1.executeUpdate();
			}
			if ( groupAckStatus != null ) {
				pStatement2 = conx.prepareStatement(UpdateGroup);
				pStatement2.setString(1, groupAckStatus);
				pStatement2.setString(2, docId);
				pStatement2.executeUpdate();
			}
		} catch (Throwable t) {
			logMsg("ITXA.updateReconcileRow exception.", t, true);
		} finally {
			if ( pStatement1 != null ) {
				try {
					pStatement1.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
			if ( pStatement2 != null ) {
				try {
					pStatement2.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
		}
	}

	/** Create a transaction record in the SPE_CORRELATION_TRANSACTION table.
	 * @param conx The JDBC connection.
	 * @param eventMap The document meta data.
	 * @param docId The document identifier that all the meta data is associated with.
	 * @param levelIndex The level index to use.*/
	private void createTransactionRow(Connection conx, Map<String, String> eventMap, String docId, int levelIndex) {
		int parametersSpecified = 0;
		PreparedStatement pStatement = null;
		try {
			// Prepare the SQL statement and set default values.
			pStatement = conx.prepareStatement(InsertTrans);
			pStatement.setString(3, null);    // SENDER_ID_QUALIFIER
			pStatement.setString(5, null);    // RECEIVER_ID_QUALIFIER
			pStatement.setString(9,  null);   // VERSION
			pStatement.setString(15, "0");    // TRANSACTION_COUNT
			pStatement.setString(17,  docId); // OBJECT_ID
			pStatement.setTimestamp(18, new Timestamp(System.currentTimeMillis())); // CREATE_DATE

			String value = null;
			String[] values = null;
			String keyValue = null;
			int levels = levelIndex + 1; // Account for zero-based index when comparing.
			for ( String key : eventMap.keySet() ) {
				keyValue = eventMap.get(key);
				if ( keyValue != null ) {
					values = keyValue.split(SplitRegex);
					if ( debug && values.length > levelSize ) {
						StringBuilder sb = new StringBuilder(200);
						sb.append("ITXA.createTransactionRow key=").append(key);
						sb.append(HasMultipleValues).append(Arrays.asList(values));
						logMsg(sb.toString(), null, false);
					}
					// This code used to loop through all the values which resulted in only using the last value.
					// Instead, get the corresponding value that matches the level or the last value.
					if ( levels > values.length ) {
						value = values[values.length - 1]; // Gets the last value.
					} else {
						value = values[levelIndex]; // Gets the corresponding level value.
					}
					if ( Standard.equals(key) ) {
						pStatement.setString(1, value);
						parametersSpecified++;
					} else if ( TransactionSenderID.equals(key) ) {
						pStatement.setString(2, value);
						parametersSpecified++;
					} else if ( TransactionSenderIDQualifier.equals(key) ) {
						pStatement.setString(3, value);
						parametersSpecified++;
					} else if ( TransactionReceiverID.equals(key) ) {
						pStatement.setString(4, value);
						parametersSpecified++;
					} else if ( TransactionReceiverIDQualifier.equals(key) ) {
						pStatement.setString(5, value);
						parametersSpecified++;
					} else if ( TransactionEnvelopeName.equals(key) ) {
						pStatement.setString(6, value);
						parametersSpecified++;
					} else if ( TransactionEnvelopeType.equals(key) ) {
						pStatement.setString(7, value);
						parametersSpecified++;
					} else if ( TransactionEnvelopeVersion.equals(key) ) {
						pStatement.setString(8, value);
						parametersSpecified++;
					} else if ( TransactionVersion.equals(key) ) {
						pStatement.setString(9, value);
						parametersSpecified++;
					} else if ( TransactionSetID.equals(key) ) {
						pStatement.setString(10, value);
						parametersSpecified++;
					} else if ( TransactionComplianceStatus.equals(key) ) {
						pStatement.setString(11, value);
						parametersSpecified++;
					} else if ( Direction.equals(key) ) {
						pStatement.setString(12, value);
						parametersSpecified++;
					} else if ( DocumentSize.equals(key) ) {
						pStatement.setInt(13, Integer.parseInt(value));
						parametersSpecified++;
					} else if ( TransactionDateTime.equals(key) ) {
						Timestamp stamp = new Timestamp(Long.parseLong(value));
						Date date = new Date(stamp.getTime());
						pStatement.setString(14, String.valueOf(date));
						parametersSpecified++;
					} else if ( TransactionCount.equals(key) ) {
						pStatement.setString(15, value);
						parametersSpecified++;
					} else if ( ContainerDocID.equals(key) ) {
						pStatement.setString(16, value);
						parametersSpecified++;
					}
				}
			}

			if ( parametersSpecified > 0 ) {
				try {
					pStatement.executeUpdate();
				} catch (Exception e) { // Mainly for duplicate errors.
					if ( debug ) {
						logMsg("ITXA.createTransactionRow exception during executeUpdate: " + e.toString(), null, false);
					}
				}
			}
		} catch (Throwable t) {
			logMsg("ITXA.createTransactionRow exception.", t, true);
		} finally {
			if ( pStatement != null ) {
				try {
					pStatement.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
		}
	}

	/** Create a group record in the SPE_CORRELATION_GROUP table.
	 * @param conx The JDBC Connection.
	 * @param eventMap The document meta data.
	 * @param docId The document identifier that all the meta data is associated with.
	 * @param levelIndex The level index to use.*/
	private void createGroupRow(Connection conx, Map<String, String> eventMap, String docId, int levelIndex) {
		int parametersSpecified = 0;
		PreparedStatement pStatement = null;
		try {
			// Prepare the SQL statement and set default values.
			pStatement = conx.prepareStatement(InsertGroup);
			pStatement.setString(3, null);    // SENDER_ID_QUALIFIER
			pStatement.setString(5, null);    // RECEIVER_ID_QUALIFIER
			pStatement.setString(9, null);    // VERSION
			pStatement.setString(13, null);   // ACK_STATUS
			pStatement.setString(14, null);   // ACK_OVERDUE_TIME
			pStatement.setString(15, "0");    // CHILD_COUNT
			pStatement.setString(19, null);   // CONTAINER_DOC_ID
			pStatement.setString(20,  docId); // OBJECT_ID
			pStatement.setTimestamp(21, new Timestamp(System.currentTimeMillis())); // CREATE_DATE

			String value = null;
			String[] values = null;
			String keyValue = null;
			int levels = levelIndex + 1; // Account for zero-based index when comparing.
			for ( String key : eventMap.keySet() ) {
				keyValue = eventMap.get(key);
				if ( keyValue != null ) {
					values = keyValue.split(SplitRegex);
					if ( debug && values.length > levelSize ) {
						StringBuilder sb = new StringBuilder(200);
						sb.append("ITXA.createGroupRow key=").append(key);
						sb.append(HasMultipleValues).append(Arrays.asList(values));
						logMsg(sb.toString(), null, false);
					}
					// This code used to loop through all the values which resulted in only using the last value.
					// Instead, get the corresponding value that matches the level or the last value.
					if ( levels > values.length ) {
						value = values[values.length - 1]; // Gets the last value.
					} else {
						value = values[levelIndex]; // Gets the corresponding level value.
					}
					if ( Standard.equals(key) ) {
						pStatement.setString(1, value);
						parametersSpecified++;
					} else if ( GroupSenderID.equals(key) ) {
						pStatement.setString(2, value);
						parametersSpecified++;
					} else if ( GroupSenderIDQualifier.equals(key) ) {
						pStatement.setString(3, value);
						parametersSpecified++;
					} else if ( GroupReceiverID.equals(key) ) {
						pStatement.setString(4, value);
						parametersSpecified++;
					} else if ( GroupReceiverIDQualifier.equals(key) ) {
						pStatement.setString(5, value);
						parametersSpecified++;
					} else if ( GroupEnvelopeName.equals(key) ) {
						pStatement.setString(6, value);
						parametersSpecified++;
					} else if ( GroupEnvelopeType.equals(key) ) {
						pStatement.setString(7, value);
						parametersSpecified++;
					} else if ( GroupEnvelopeVersion.equals(key) ) {
						pStatement.setString(8, value);
						parametersSpecified++;
					} else if ( GroupVersion.equals(key) ) {
						pStatement.setString(9, value);
						parametersSpecified++;
					} else if ( GroupControlNumber.equals(key) ) {
						pStatement.setString(10, value);
						parametersSpecified++;
					} else if ( FunctionalID.equals(key) ) {
						pStatement.setString(11, value);
						parametersSpecified++;
					} else if ( GroupComplianceStatus.equals(key) ) {
						pStatement.setString(12, value);
						parametersSpecified++;
					} else if ( GroupAckStatus.equals(key) ) {
						pStatement.setString(13, value);
						parametersSpecified++;
					} else if ( GroupOverdueTime.equals(key) ) {
						Timestamp stamp = new Timestamp(Long.parseLong(value));
						pStatement.setTimestamp(14, stamp);
						parametersSpecified++;
					} else if ( TransactionCount.equals(key) ) {
						pStatement.setString(15, value);
						parametersSpecified++;
					} else if ( Direction.equals(key) ) {
						pStatement.setString(16, value);
						parametersSpecified++;
					} else if ( DocumentSize.equals(key) ) {
						pStatement.setInt(17, Integer.parseInt(value));
						parametersSpecified++;
					} else if ( GroupDateTime.equals(key) ) {
						Timestamp stamp = new Timestamp(Long.parseLong(value));
						Date date = new Date(stamp.getTime());
						pStatement.setString(18, String.valueOf(date));
						parametersSpecified++;
					} else if ( ContainerDocID.equals(key) ) {
						pStatement.setString(19, value);
						parametersSpecified++;
					}
				}
			}

			if ( parametersSpecified > 0 ) {
				try {
					pStatement.executeUpdate();
				} catch (Exception e) { // Mainly for duplicate errors.
					if ( debug ) {
						logMsg("ITXA.createGroupRow exception during executeUpdate: " + e.toString(), null, false);
					}
				}
			}
		} catch (Throwable t) {
			logMsg("ITXA.createGroupRow exception.", t, true);
		} finally {
			if ( pStatement != null ) {
				try {
					pStatement.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
		}
	}

	/** Create an interchange record in the SPE_CORRELATION_INTERCHANGE table.
	 * @param conx The JDBC connection.
	 * @param eventMap The document meta data.
	 * @param docId The document identifier that all the meta data is associated with.
	 * @param levelIndex The level index to use.*/
	private void createInterchangeRow(Connection conx, Map<String, String> eventMap, String docId, int levelIndex) {
		int parametersSpecified = 0;
		PreparedStatement pStatement = null;
		try {
			// Prepare the SQL statement and set default values.
			pStatement = conx.prepareStatement(InsertInter);
			pStatement.setString(3, null);    // SENDER_ID_QUALIFIER
			pStatement.setString(5, null);    // RECEIVER_ID_QUALIFIER
			pStatement.setString(6, null);    // ENVELOPE_NAME
			pStatement.setString(8, null);    // ENVELOPE_VERSION
			pStatement.setString(9, "");      // CONTROL_NUMBER
			pStatement.setString(11, null);   // ACK_REQUESTED
			pStatement.setString(12, null);   // ACK_STATUS
			pStatement.setString(13, null);   // ACK_OVERDUE_TIME
			pStatement.setString(14, "0");    // CHILD_COUNT
			pStatement.setString(17,  null);  // INTERCHANGE_DATE
			pStatement.setString(18,  docId); // OBJECT_ID
			pStatement.setTimestamp(19, new Timestamp(System.currentTimeMillis())); // CREATE_DATE

			String value = null;
			String[] values = null;
			String keyValue = null;
			int levels = levelIndex + 1; // Account for zero-based index when comparing.
			for ( String key : eventMap.keySet() ) {
				keyValue = eventMap.get(key);
				if ( keyValue != null ) {
					values = keyValue.split(SplitRegex);
					if ( debug && values.length > levelSize ) {
						StringBuilder sb = new StringBuilder(200);
						sb.append("ITXA.createInterchangeRow key=").append(key);
						sb.append(HasMultipleValues).append(Arrays.asList(values));
						logMsg(sb.toString(), null, false);
					}
					// This code used to loop through all the values which resulted in only using the last value.
					// Instead, get the corresponding value that matches the level or the last value.
					if ( levels > values.length ) {
						value = values[values.length - 1]; // Gets the last value.
					} else {
						value = values[levelIndex]; // Gets the corresponding level value.
					}
					if ( Standard.equals(key) ) {
						pStatement.setString(1, value);
						parametersSpecified++;
					} else if ( InterchangeSenderID.equals(key) ) {
						pStatement.setString(2, value);
						parametersSpecified++;
					} else if ( InterchangeSenderIDQualifier.equals(key) ) {
						pStatement.setString(3, value);
						parametersSpecified++;
					} else if ( InterchangeReceiverID.equals(key) ) {
						pStatement.setString(4, value);
						parametersSpecified++;
					} else if ( InterchangeReceiverIDQualifier.equals(key) ) {
						pStatement.setString(5, value);
						parametersSpecified++;
					} else if ( InterchangeEnvelopeName.equals(key) ) {
						pStatement.setString(6, value);
						parametersSpecified++;
					} else if ( InterchangeEnvelopeType.equals(key) ) {
						pStatement.setString(7, value);
						parametersSpecified++;
					} else if ( InterchangeEnvelopeVersion.equals(key) ) {
						pStatement.setString(8, value);
						parametersSpecified++;
					} else if ( InterchangeControlNumber.equals(key) ) {
						pStatement.setString(9, value);
						parametersSpecified++;
					} else if ( InterchangeComplianceStatus.equals(key) ) {
						pStatement.setString(10, value);
						parametersSpecified++;
					} else if ( InterchangeAckRequested.equals(key) ) {
						pStatement.setString(11, value);
						parametersSpecified++;
					} else if ( InterchangeAckStatus.equals(key) ) {
						pStatement.setString(12, value);
						parametersSpecified++;
					} else if ( InterchangeOverdueTime.equals(key) ) {
						Timestamp stamp = new Timestamp(Long.parseLong(value));
						pStatement.setTimestamp(13, stamp);
						parametersSpecified++;
					} else if ( GroupCount.equals(key) ) {
						pStatement.setString(14, value);
						parametersSpecified++;
					} else if ( Direction.equals(key) ) {
						pStatement.setString(15, value);
						parametersSpecified++;
					} else if ( DocumentSize.equals(key) ) {
						pStatement.setInt(16, Integer.parseInt(value));
						parametersSpecified++;
					} else if ( InterchangeDateTime.equals(key) ) {
						Timestamp stamp = new Timestamp(Long.parseLong(value));
						Date date = new Date(stamp.getTime());
						pStatement.setString(17, String.valueOf(date));
						parametersSpecified++;
					}
				}
			}

			if ( parametersSpecified > 0 ) {
				try {
					pStatement.executeUpdate();
				} catch (Exception e) { // Mainly for duplicate errors.
					if ( debug ) {
						logMsg("ITXA.createInterchangeRow exception during executeUpdate: " + e.toString(), null, false);
					}
				}
			}
		} catch (Throwable t) {
			logMsg("ITXA.createInterchangeRow exception.", t, true);
		} finally {
			if ( pStatement != null ) {
				try {
					pStatement.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
		}
	}

	/** Create an name value pair records in the SPE_CORRELATION_OTHER table for anything remaining that didn't fit into the three main tables.
	 * @param conx The JDBC connection.
	 * @param eventMap The document meta data.
	 * @param docId The document identifier that all the meta data is associated with. */
	private void persistOtherCorrelations(Connection conx, Map<String, String> eventMap, String docId) {
		PreparedStatement pStatement = null;
		try {
			removeNonOtherKeys(eventMap);
			pStatement = conx.prepareStatement(InsertOther);
			String[] values = null;
			String keyValue = null;
			for ( String key : eventMap.keySet() ) {
				keyValue = eventMap.get(key);
				if ( keyValue != null ) {
					values = keyValue.split(SplitRegex);
					for ( String value : values ) {
						// Ignore the event name of attachments.
						if ( !attachments.equalsIgnoreCase(key) ) {
							pStatement.setString(1, key);
							pStatement.setString(2, value);
							pStatement.setString(3, docId);
							pStatement.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
							try {
								pStatement.executeUpdate();
							} catch (Exception e) { // Mainly for duplicate errors.
								if ( debug ) {
									logMsg("ITXA.persistOtherCorrelations exception during executeUpdate: " + e.toString(), null, false);
								}
							}
						}
					}
				}
			}
		} catch (Throwable t) {
			logMsg("ITXA.persistOtherCorrelations exception.", t, true);
		} finally {
			if ( pStatement != null ) {
				try {
					pStatement.close();
				} catch (Throwable t) {
					t = null; // Ignore.
				}
			}
		}
	}

	/** Removes any correlations that should not be persisted to the SPE_CORRELATION_OTHER table.
	 * @param eventMap The document meta data. */
	private void removeNonOtherKeys(Map<String, String> eventMap) {
		eventMap.remove("location"); // location = SPE
		eventMap.remove("nodeName"); // nodeName = itxa/SPE/{host}
		eventMap.remove("type");     // type = event

		eventMap.remove(Standard);
		eventMap.remove(Direction);
		eventMap.remove(DocumentSize);
		eventMap.remove(Level);

		eventMap.remove(InterchangeSenderID);
		eventMap.remove(InterchangeSenderIDQualifier);
		eventMap.remove(InterchangeReceiverID);
		eventMap.remove(InterchangeReceiverIDQualifier);
		eventMap.remove(InterchangeEnvelopeName);
		eventMap.remove(InterchangeEnvelopeType);
		eventMap.remove(InterchangeEnvelopeVersion);
		eventMap.remove(InterchangeControlNumber);
		eventMap.remove(InterchangeComplianceStatus);
		eventMap.remove(InterchangeAckRequested);
		eventMap.remove(InterchangeAckStatus);
		eventMap.remove(InterchangeOverdueTime);
		eventMap.remove(InterchangeDateTime);

		eventMap.remove(GroupCount);
		eventMap.remove(GroupSenderID);
		eventMap.remove(GroupSenderIDQualifier);
		eventMap.remove(GroupReceiverID);
		eventMap.remove(GroupReceiverIDQualifier);
		eventMap.remove(GroupEnvelopeName);
		eventMap.remove(GroupEnvelopeType);
		eventMap.remove(GroupEnvelopeVersion);
		eventMap.remove(GroupVersion);
		eventMap.remove(GroupControlNumber);
		eventMap.remove(GroupComplianceStatus);
		eventMap.remove(GroupAckStatus);
		eventMap.remove(GroupOverdueTime);
		eventMap.remove(GroupDateTime);
		eventMap.remove(ContainerDocID);
		eventMap.remove(FunctionalID);

		eventMap.remove(TransactionCount);
		eventMap.remove(TransactionSenderID);
		eventMap.remove(TransactionSenderIDQualifier);
		eventMap.remove(TransactionReceiverID);
		eventMap.remove(TransactionReceiverIDQualifier);
		eventMap.remove(TransactionEnvelopeName);
		eventMap.remove(TransactionEnvelopeType);
		eventMap.remove(TransactionEnvelopeVersion);
		eventMap.remove(TransactionVersion);
		eventMap.remove(TransactionSetID);
		eventMap.remove(TransactionComplianceStatus);
		eventMap.remove(TransactionDateTime);
	}

	/** Logs a message.
	 * @param type2str The event type as a string.
	 * @param msg The message to log.
	 * @param map2str The event map as a string. */
	private void logMsg(String type2str, String msg, String map2str) {
		final String prefix = "ITXA.summarize: ";
		int size = prefix.length();
		if ( type2str != null ) {
			size += type2str.length();
		}
		if ( msg != null ) {
			size += msg.length();
		}
		if ( map2str != null ) {
			size += map2str.length();
		}
		StringBuilder sb = new StringBuilder(size);
		sb.append(prefix);
		if ( type2str != null ) {
			sb.append(type2str);
		}
		if ( msg != null ) {
			sb.append(msg);
		}
		if ( map2str != null ) {
			sb.append(map2str);
		}
		logMsg(sb.toString(), null, false);
	}

	/** Logs a message.
	 * @param msg The message to log.
	 * @param t An optional Throwable exception.
	 * @param logError Determines whether to log as an error or info. */
	private void logMsg(String msg, Throwable t, boolean logError) {
		if ( msg != null ) {
			int size = msg.length();
			StringBuilder sb = null;
			if ( debugToStdOut ) {
				String date = sdf.format(new Date());
				size += NL.length();
				size += date.length() + 2; // +2 for ": "
				sb = new StringBuilder(size);
				sb.append(NL).append(date).append(": ").append(msg);
			} else {
				sb = new StringBuilder(msg);
			}
			msg = sb.toString();
			if ( debugToStdOut ) {
				// These messages will also show up in the Engine_{date_time}.log preceded by [ProcessSummaryWorker-nn].
				System.out.println(msg);
				if ( t != null ) {
					t.printStackTrace();
				}
			} else {
				// These messages will only show up in the Engine_{date_time}.log preceded by [ProcessSummaryWorker-nn].
				if ( logError ) {
					if ( t != null ) {
						Log.error(msg, t);
					} else {
						Log.error(msg);
					}
				} else {
					Log.info(msg);
				}
			}
		}
	}

	/** Gets the properties from the specified file name.
	 * @param filename The file name to get the properties from.
	 * @return A Properties object if successful, otherwise null. */
	private Properties getProperties(String filename) {
		Properties props = null;
		File file = new File(filename);
		if ( file.exists() ) {
			props = new Properties();
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				props.load(fis);
			} catch (Throwable t) {
				logMsg(t.toString(), null, false);
			} finally {
				if ( fis != null ) {
					try {
						fis.close();
					} catch (Throwable t) {
						fis = null;
					}
				}
			}
		}
		return props;
	}
}
